package com.example.splitmatealpha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
