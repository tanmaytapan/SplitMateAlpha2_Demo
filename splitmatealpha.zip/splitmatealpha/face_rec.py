import cv2
import numpy as np
from picamera2 import Picamera2

label_to_name = {
    0: "Bhavesh",
}


CONFIDENCE_THRESHOLD = 100  
def recognize_faces(model_file):

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(model_file)
    face_cascade = cv2.CascadeClassifier('/home/Bhavesh/Desktop/Splitmate/Scripts/haarcascade_frontalface_default.xml')

    picam2 = Picamera2()
    picam2.configure(picam2.create_preview_configuration(main={"format": 'XRGB8888', "size": (640, 480)}))
    picam2.start()

    while True:
        
        frame = picam2.capture_array()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        for (x, y, w, h) in faces:
            face_img = gray[y:y+h, x:x+w]
            label, confidence = recognizer.predict(face_img)

            
            if confidence < CONFIDENCE_THRESHOLD:
                name = label_to_name.get(label, "Unknown")
            else:
                name = "Unknown"

            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, name, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        cv2.imshow("Face Recognition", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    picam2.close()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    recognize_faces('face_recognition_model.yml')
