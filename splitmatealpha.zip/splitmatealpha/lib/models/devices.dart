class Device {
  final String id;
  final String name;
  final double usage;

  Device({required this.id, required this.name, required this.usage});
}
