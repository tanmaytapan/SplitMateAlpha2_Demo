class Tenant {
  final String id;
  final String name;
  final List<String> devices;

  Tenant({required this.id, required this.name, required this.devices});
}
