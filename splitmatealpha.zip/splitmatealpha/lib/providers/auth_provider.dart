import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Method for user login
  Future<void> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      notifyListeners();
    } catch (e) {
      throw e; // Consider handling errors more gracefully here
    }
  }

  // Updated return type from Future<void> to Future<UserCredential>
  Future<UserCredential> signup(String email, String password) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);
      notifyListeners();
      return userCredential; // This now matches the method's return type
    } catch (e) {
      throw e; // Consider handling errors more gracefully here
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    notifyListeners();
  }
}
