import 'package:flutter/material.dart';

class PrincipalDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Principal Tenant Dashboard")),
      body: Center(
        child: Text("List of Tenants and Devices"),
      ),
    );
  }
}
