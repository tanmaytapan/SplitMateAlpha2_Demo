import 'package:flutter/material.dart';

class TenantDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tenant Dashboard")),
      body: Center(
        child: Text("List of Devices"),
      ),
    );
  }
}
