import 'package:flutter/material.dart';

class AuthButtonWidget extends StatelessWidget {
  final String label;
  final Function() onTap;

  AuthButtonWidget({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onTap,
      child: Text(label),
      style: ButtonStyle(
        backgroundColor:
            WidgetStateProperty.all(Theme.of(context).primaryColor),
        padding: WidgetStateProperty.all(
            EdgeInsets.symmetric(horizontal: 20, vertical: 10)),
        textStyle: WidgetStateProperty.all(TextStyle(fontSize: 16)),
      ),
    );
  }
}
