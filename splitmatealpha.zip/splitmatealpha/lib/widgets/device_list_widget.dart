import 'package:flutter/material.dart';
import '../models/devices.dart';

class DeviceListWidget extends StatelessWidget {
  final List<Device> devices;

  DeviceListWidget({required this.devices});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: devices.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: Icon(Icons.device_hub),
          title: Text(devices[index].name),
          subtitle: Text("Usage: ${devices[index].usage.toString()} kWh"),
          trailing: Icon(Icons.arrow_forward_ios),
          onTap: () {
            // You can implement navigation to a detailed view of the device
          },
        );
      },
    );
  }
}
