import 'package:flutter/material.dart';
import '../models/tenant.dart';

class TenantListWidget extends StatelessWidget {
  final List<Tenant> tenants;

  TenantListWidget({required this.tenants});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: tenants.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: Icon(Icons.person),
          title: Text(tenants[index].name),
          trailing: IconButton(
            icon: Icon(Icons.delete),
            onPressed: () {
              // Logic to remove tenant
            },
          ),
          onTap: () {
            // Possibly navigate to a tenant detail page
          },
        );
      },
    );
  }
}
